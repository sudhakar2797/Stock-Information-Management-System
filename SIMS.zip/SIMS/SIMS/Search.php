<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Stack Management System</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
   </head><!--/head-->

<body data-spy="scroll" data-target="#navbar" data-offset="0">
    <header id="header" role="banner">
        <div class="container">
            <div id="navbar" class="navbar navbar-default">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="welcome.php"></a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="welcome.php"><i class="icon-home"></i></a></li>
                       <li><a href="Search.php">Search</a></li>

                        <li><a href="Update.php">Update</a></li>
                        <li><a href="Newupdate.php">New Product</a></li>
                        <li><a href="report.php">Report</a></li>

                        <li><a href="Display.php">Display</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </header><!--/#header-->

    <section id="main-slider" class="carousel" style="height: 100px">
        <div class="carousel-inner">
            <div class="item active">
                <div class="container">
                    <div class="carousel-content">
                        <h1>Search</h1>
                    </div>
                </div>
            </div><!--/.item-->
            <div class="item">
                <div class="container">
                    <div class="carousel-content">
                        <h1 style="font-size: 45px">Department of Mechanical Engineering</h1>
                    </div>
                </div>
            </div><!--/.item-->
        </div><!--/.carousel-inner-->
        
        
        
        
        <a class="prev" href="#main-slider" data-slide="prev"><i class="icon-angle-left"></i></a>
        <a class="next" href="#main-slider" data-slide="next"><i class="icon-angle-right"></i></a>
    </section><!--/#main-slider-->

    <section id="services">
        <div class="container">
            <div class="box first"><br><br><br><?php if(isset($_POST['search'])){
                
               $searchitem=$_POST['item'];
      require 'dbconnect.php';   
                                    $query="SELECT * FROM stock WHERE ProductName = '$searchitem'";                
                                    $sql = $conn->query($query); 
                                        if($sql->num_rows >0) {
                                            while($row = $sql->fetch_assoc())
                                            {?>
                                               
                                       
                   
    <section id="pricing">
        <div class="container">
            <center> <div class="box" style="width:70%">
         
                        <ul class="plan featured">
                            <li class="plan-price">Details</li>
                            <li style="font-size: 20px;color:mediumblue;"><b style="font-size: 18px;color:#000;">RackNo&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b><?php echo $row['RackNo'];?></li>

                            <li style="font-size: 20px;color:darkorange"><?php echo $row['ProductName'];?></li>
                            <li style="font-size: 20px;color:darkviolet;"><b style="font-size: 18px;color:#000;">Quantity&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b><?php echo $row['Quantity'];?></li>
                        </ul>
                   
                    
               </div> </center>
            </div> 
    </section>
      
                                                
                                                
                                                
                                                
                                        <?php  }}else{?>
                                                      
    <section id="pricing">
        <div class="container">
            <center> <div class="box" style="width:70%">
         
                        <ul class="plan featured">
                           <center> <li class="plan-price" style="font-size: 25px;border-radius: 25px;width: 50%">Enter Valid Data</li>
                           </center></ul>
                   
                    
               </div> </center>
            </div> 
    </section>    
                                      <?php  }
                                  mysqli_close($conn);
                
                
                
                
                                  echo '<br><br><br>';  
            }?>
                
                
                
                <style>

#page-wrapper {
  width: 600px;
  background: #FFFFFF;
  padding: 1em;
  margin: 1em auto;
  border-top: 5px solid #69c773;
  box-shadow: 0 2px 10px rgba(0,0,0,0.8);
}

h1 {
  margin-top: 0;
}

label {
  display: block;
  margin-top: 2em;
  margin-bottom: 0.5em;
  color: #999999;
}

input {
  width: 100%;
  padding: 0.5em 0.5em;
  font-size: 1.2em;
  border-radius: 3px;
  border: 1px solid #D9D9D9;
}

button {
  display: inline-block;
  border-radius: 3px;
  border: none;
  font-size:20px;
  padding: 10px 15px;
  background: #69c773;
  border-bottom: 1px solid #498b50;
  color: white;
  -webkit-font-smoothing: antialiased;
  font-weight: bold;
  margin: 0;
  width: 30%;
  text-align: center;
}

button:hover, button:focus {
  opacity: 0.75;
  cursor: pointer;
}

button:active {
  opacity: 1;
  box-shadow: 0 -3px 10px rgba(0, 0, 0, 0.1) inset;
}

        
    </style>

<script>

// Get the <datalist> and <input> elements.
var dataList = document.getElementById('json-datalist');
var input = document.getElementById('ajax');

// Create a new XMLHttpRequest.
var request = new XMLHttpRequest();

// Handle state changes for the request.
request.onreadystatechange = function(response) {
  if (request.readyState === 4) {
    if (request.status === 200) {
      // Parse the JSON
      var jsonOptions = JSON.parse(request.responseText);
  
      // Loop over the JSON array.
      jsonOptions.forEach(function(item) {
        // Create a new <option> element.
        var option = document.createElement('option');
        // Set the value using the item in the JSON array.
        option.value = item;
        // Add the <option> element to the <datalist>.
        dataList.appendChild(option);
      });
      
      // Update the placeholder text.
      input.placeholder = "e.g. datalist";
    } else {
      // An error occured :(
      input.placeholder = "Couldn't load datalist options :(";
    }
  }
};

// Update the placeholder text.
input.placeholder = "Loading options...";

// Set up and make the request.
request.open('GET', 'https://s3-us-west-2.amazonaws.com/s.cdpn.io/4621/html-elements.json', true);
request.send();

</script>

<div id="page-wrapper">
  <h1>Type To Search Here</h1>
  <form action="Search.php" method="post">
  <label for="default">Pick a Product</label>
  <input type="text" id="default" name="item" list="languages" placeholder="e.g.Register" required>
  
  <datalist id="languages">
      
      <?php
      require 'dbconnect.php';   
                                    $query="SELECT ProductName FROM stock";                
                                    $sql = $conn->query($query); 
                                        if($sql->num_rows >0) {
                                            while($row = $sql->fetch_assoc())
                                            {?>
      <option value="<?php echo $row['ProductName'];?>">
                                         <?php }}
                                  mysqli_close($conn);?>
  </datalist>
  <br><br><br>
  <center> <button name="search">Search</button></center>
  
  
  
  </form>
</div>
                
                
                
                
                
                
                
                
                
                
                
                
                <br><br><br><br><br><br><br>
                
                <br><br><br>
            </div><!--/.box-->
        </div><!--/.container-->
    </section><!--/#services-->

    <footer id="footer">
        <div class="container">
            <div class="row">
            <enter>
<?php echo "<p><center>Copyright &copy; 1998 - " . date("Y") . " Kamaraj  of College Engineering & Technology</center></p>"; ?>
                    </enter>  </div>
               
        </div>
    </footer><!--/#footer-->

</body>
</html>