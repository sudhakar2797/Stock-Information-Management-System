<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Stack Management System</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <style>
    .button{cursor: pointer;
  background: #33b5e5;
  width: 10%;
  border: 0;
  padding: 10px 15px;
  color: #ffffff;
  -webkit-transition: 0.3s ease;
  transition: 0.3s ease;
  border-radius: 25px;
    }
    .button:hover{
        background-color: #21a6d8;
    }
    </style>
   </head><!--/head-->

<body data-spy="scroll" data-target="#navbar" data-offset="0">
    <header id="header" role="banner">
        <div class="container">
            <div id="navbar" class="navbar navbar-default">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="welcome.php"></a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="welcome.php"><i class="icon-home"></i></a></li>
                        <li><a href="Search.php">Search</a></li>

                        <li><a href="Update.php">Update</a></li>
                        <li><a href="Newupdate.php">New Product</a></li>
                        <li><a href="report.php">Report</a></li>

                        <li><a href="Display.php">Display</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </header><!--/#header-->

    <section id="main-slider" class="carousel" style="height: 100px">
        <div class="carousel-inner">
            <div class="item active">
                <div class="container">
                    <div class="carousel-content">
                        <h1>Display</h1>
                    </div>
                </div>
            </div><!--/.item-->
            <div class="item">
                <div class="container">
                    <div class="carousel-content">
                        <h1 style="font-size: 45px">Department of Mechanical Engineering</h1>
                    </div>
                </div>
            </div><!--/.item-->
        </div><!--/.carousel-inner-->
        
        
        
        
        <a class="prev" href="#main-slider" data-slide="prev"><i class="icon-angle-left"></i></a>
        <a class="next" href="#main-slider" data-slide="next"><i class="icon-angle-right"></i></a>
    </section><!--/#main-slider-->

    <section id="services">
        <div class="container">
            <div class="box first"><br>
                <center> <a href="download.php"><button class="button">Download</button></a></center><br><br>
                <link href="css/component.css" rel="stylesheet">
                <?php 
                 echo'<table>';
                echo'<thead>';
                    echo'<tr>';
                        echo'<th>RackNo</th>';
                        echo'<th>ProductId</th>';
                        echo'<th>ProductName</th>';
                        echo'<th>Quantity</th>';
                    echo'</tr>';
                echo'</thead>';
            echo'<tbody>';
            
            require 'dbconnect.php';   
                
                    $query="SELECT * FROM stock";
                    $sql = $conn->query($query); 
                        if($sql->num_rows >0) {
                            while($row = $sql->fetch_assoc()) 
                            {
                                    echo '<tr><td style="color:darkBlue" class="user-name">'.$row['RackNo'] .'</td><td style="color:#f67854" >'.$row['ProductID'] .'</td><td style="color:#357ae8" class="user-name">'.$row['ProductName'] .'</td><td style="color:darkgreen" class="user-phone">'.$row['Quantity'].'</td>';
                                                         
                            }
                        }else{
                                    echo '<tr><td colspan="4">Not Available</td></tr>';
                                } 
             
                ?>
                
                
                
            </div><!--/.box-->
        </div><!--/.container-->
    </section><!--/#services-->

</body>
</html>