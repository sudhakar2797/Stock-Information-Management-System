<?php $error="";
if (isset($_POST['update'])){
    $quantity=$_POST['quan'];
    $item=$_POST['item'];
    $uquan=$quantity;
     require 'dbconnect.php';   
                                    $query="SELECT Quantity FROM stock WHERE ProductName='$item'";                
                                    $sql = $conn->query($query); 
                                        if($sql->num_rows >0) { 
                                          $row = $sql->fetch_assoc();
                                            $total=$row['Quantity'];
                                            if($total<$quantity){
                                              $error="Enter Valid Data";  
                                            }else{
                                     $quan=$total-$quantity;
                                    $sql="UPDATE stock SET Quantity = '$quan' WHERE ProductName='$item'" ;  
                                    
                                       
                                  $date= date('Y/m/d');
                                  $type="withdrawal";
                                  
        $stmt = $conn->prepare("INSERT INTO `transaction`( `Date`, `Type`, `ProductName`, `Quantity`) VALUES (?,?,?,?)");
        $stmt->bind_param("ssss",$date,$type,$item,$uquan);
                                    
                                    if((mysqli_query($conn,$sql))&&($stmt->execute())){
                                    
                                   $error="Successfully Updated";  
   
                                            }}
     } else {
       $error="Enter Valid Data";  
     
    }
    
    
    
}



?>

<?php
if(isset($_POST['insert'])){
   $pname=$_POST['insertitem'];
   $quan=$_POST['quan'];
   $uquan=$quan;
     require 'dbconnect.php';   
                                    $query="SELECT Quantity FROM stock WHERE ProductName='$pname'";                
                                    $sql = $conn->query($query); 
                                        if($sql->num_rows >0) {
                                          $row = $sql->fetch_assoc();
                                            $total=$row['Quantity'];
                                             $quan=$total+$quan;
                                    $sql="UPDATE stock SET Quantity = '$quan' WHERE Productname='$pname'" ; 
                                    
                                  $date= date('Y/m/d');
                                  $type="store";
                                  
        $stmt = $conn->prepare("INSERT INTO `transaction`( `Date`, `Type`, `ProductName`, `Quantity`) VALUES (?,?,?,?)");
        $stmt->bind_param("ssss",$date,$type,$pname,$uquan);
                                    
                                    if((mysqli_query($conn,$sql))&&($stmt->execute())){
                                    $error="Successfully Inserted";}  
   else{
                                                                        $error="Enter Valid Data";  
   }                  
                                            
                                                
                                        } else {
                                                                                      $error="Enter Valid Data";  
    
                                        }                                             
                                           
    
}





?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>stock Management System</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
   </head><!--/head-->

<body data-spy="scroll" data-target="#navbar" data-offset="0">
    <header id="header" role="banner">
        <div class="container">
            <div id="navbar" class="navbar navbar-default">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="welcome.php"></a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="welcome.php"><i class="icon-home"></i></a></li>
                        <li><a href="Search.php">Search</a></li>

                        <li><a href="Update.php">Update</a></li>
                        <li><a href="Newupdate.php">New Product</a></li>
                        <li><a href="report.php">Report</a></li>

                        <li><a href="Display.php">Display</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </header><!--/#header-->

    <section id="main-slider" class="carousel" style="height: 100px">
        <div class="carousel-inner">
            <div class="item active">
                <div class="container">
                    <div class="carousel-content">
                        <h1>Update</h1>
                    </div>
                </div>
            </div><!--/.item-->
            <div class="item">
                <div class="container">
                    <div class="carousel-content">
                        <h1 style="font-size: 45px">Department of Mechanical Engineering</h1>
                    </div>
                </div>
            </div><!--/.item-->
        </div><!--/.carousel-inner-->
        
        
        
        
        <a class="prev" href="#main-slider" data-slide="prev"><i class="icon-angle-left"></i></a>
        <a class="next" href="#main-slider" data-slide="next"><i class="icon-angle-right"></i></a>
    </section><!--/#main-slider-->

    <section id="services">
        <div class="container">
            <div class="box first"><br><br><br><br>
                
                
                
                
              
<?php if($error!=""){?>
                        <link href="css/alert.css" rel="stylesheet">
<center><div class="alert info">
  <span class="closebtn">&times;</span>  
      <?php echo $error?></div></center><?php }?>

                                     <script>
var close = document.getElementsByClassName("closebtn");
var i;

for (i = 0; i < close.length; i++) {
    close[i].onclick = function(){
        var div = this.parentElement;
        div.style.opacity = "0";
        setTimeout(function(){ div.style.display = "none"; }, 600);
    }
}
</script>
                
    <div>
    <link rel="stylesheet" href="css/style.css">
<div class="login-wrap">
	<div class="login-html">
		<input id="tab-1" type="radio" name="tab" class="sign-in" checked><label for="tab-1" class="tab">UPDATE</label>
		<input id="tab-2" type="radio" name="tab" class="sign-up"><label for="tab-2" class="tab">INSERT </label>
                <div class="login-form">
                    <form action="update.php" method="post">
			<div class="sign-in-htm">
				
				<div class="group">
<div id="page-wrapper">
    					<label for="default" class="label">Product Name</label>
    <input type="text" id="default" class="input" name="item" list="languages" placeholder="e.g.Register">
  <datalist id="languages">
    
      <?php
      require 'dbconnect.php';   
                                    $query="SELECT ProductName FROM stock";                
                                    $sql = $conn->query($query); 
                                        if($sql->num_rows >0) {
                                            while($row = $sql->fetch_assoc())
                                            {?>
      <option value="<?php echo $row['ProductName'];?>">
                                         <?php }}
                                  mysqli_close($conn);?>
  </datalist></div>
                                </div><br>
				<div class="group">
					<label for="pass" class="label">Amount Of Distribution </label>
                                        <input id="pass" type="text" class="input" name="quan" placeholder="Count in number" data-type="password" required>
				</div><br>
				<div class="group">
					<input type="submit" name="update" class="button" value="UPDATE">
				</div>
				<div class="hr"></div>
				
                        </div></form>
                    
                    
                    <form action="update.php" method="post">
			<div class="sign-up-htm">
				
				<div class="group">
				
                                
                                <label for="default" class="label">Product Name</label>
                                <input type="text" id="default" class="input" name="insertitem" list="languages" placeholder="e.g.Register" required>
  <datalist id="languages">
    
      <?php
      require 'dbconnect.php';   
                                    $query="SELECT ProductName FROM stock";                
                                    $sql = $conn->query($query); 
                                        if($sql->num_rows >0) {
                                            while($row = $sql->fetch_assoc())
                                            {?>
      <option value="<?php echo $row['ProductName'];?>">
                                         <?php }}
                                  mysqli_close($conn);?>
  </datalist>
                                
                                
                                
                                
                                </div>
				<div class="group">
					<label for="pass" class="label">Quantity</label>
                                        <input id="pass" type="text" class="input" name="quan" placeholder="Amount In Count" data-type="text" required>
				</div><br>
				<div class="group">
					<input type="submit" class="button" name="insert" value="ADD TO STORE">
				</div>
				<div class="hr"></div>
                         </div>
                    </form>
		</div>
	</div>
</div>
                
                
                
                
                
                
                
                
                
                
                <br><br><br><br><br><br><br><br><br>
            </div><!--/.box-->
        </div><!--/.container-->
    </section><!--/#services-->

    <footer id="footer">
        <div class="container">
            <div class="row">
            <enter>
<?php echo "<p><center>Copyright &copy; 1998 - " . date("Y") . " Kamaraj  of College Engineering & Technology</center></p>"; ?>
                    </enter>  </div>
               
        </div>
    </footer><!--/#footer-->
                                
<script>

// Get the <datalist> and <input> elements.
var dataList = document.getElementById('json-datalist');
var input = document.getElementById('ajax');

// Create a new XMLHttpRequest.
var request = new XMLHttpRequest();

// Handle state changes for the request.
request.onreadystatechange = function(response) {
  if (request.readyState === 4) {
    if (request.status === 200) {
      // Parse the JSON
      var jsonOptions = JSON.parse(request.responseText);
  
      // Loop over the JSON array.
      jsonOptions.forEach(function(item) {
        // Create a new <option> element.
        var option = document.createElement('option');
        // Set the value using the item in the JSON array.
        option.value = item;
        // Add the <option> element to the <datalist>.
        dataList.appendChild(option);
      });
      
      // Update the placeholder text.
      input.placeholder = "e.g. datalist";
    } else {
      // An error occured :(
      input.placeholder = "Couldn't load datalist options :(";
    }
  }
};

// Update the placeholder text.
input.placeholder = "Loading options...";

// Set up and make the request.
request.open('GET', 'https://s3-us-west-2.amazonaws.com/s.cdpn.io/4621/html-elements.json', true);
request.send();

</script>
</body>
</html>