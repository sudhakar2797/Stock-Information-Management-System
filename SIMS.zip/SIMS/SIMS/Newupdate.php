<?php if(PHP_SESSION_NONE){
session_start();} ?>
<?php
if(isset($_POST['go'])){
    require 'dbconnect.php';
     $rno=$_POST['rackno'];
     $pname=$_POST['pname'];
   $quan=$_POST['quan'];
    
      $stmt = $conn->prepare("INSERT INTO `stock`(`RackNo`, `ProductName`, `Quantity`) VALUES (?,?,?)");
        $stmt->bind_param("isi",$rno,$pname,$quan);
                            if(($stmt->execute())){
                                $msg="Successfully Inserted";
                            }
                            else{
                                $msg="Please Try Again";
                            }
               
    
    
    
    
}








?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Stack Management System</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
   </head><!--/head-->

<body data-spy="scroll" data-target="#navbar" data-offset="0">
    <header id="header" role="banner">
        <div class="container">
            <div id="navbar" class="navbar navbar-default">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="welcome.php"></a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav">
                    <li class="active"><a href="welcome.php"><i class="icon-home"></i></a></li>
                        
                        <li><a href="Search.php">Search</a></li>

                        <li><a href="Update.php">Update</a></li>
                        <li><a href="Newupdate.php">New Product</a></li>
                        <li><a href="report.php">Report</a></li>

                        <li><a href="Display.php">Display</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </header><!--/#header-->

    <section id="main-slider" class="carousel" style="height: 100px">
        <div class="carousel-inner">
            <div class="item active">
                <div class="container">
                    <div class="carousel-content">
                        <h1>New Stock</h1>
                    </div>
                </div>
            </div><!--/.item-->
            <div class="item">
                <div class="container">
                    <div class="carousel-content">
                        <h1 style="font-size: 45px">Department of Mechanical Engineering</h1>
                    </div>
                </div>
            </div><!--/.item-->
        </div><!--/.carousel-inner-->
        
        
        
        
        <a class="prev" href="#main-slider" data-slide="prev"><i class="icon-angle-left"></i></a>
        <a class="next" href="#main-slider" data-slide="next"><i class="icon-angle-right"></i></a>
    </section><!--/#main-slider-->

    <section id="services">
        <div class="container">
            <div class="box first"><br><br><br>
               
                
                          <?php if(!empty($msg)){?>
            <link href="css/alert.css" rel="stylesheet">
                                      <center>  <div class="alert info" >
                                        <span class="closebtn">&times;</span>  
                                       <?php  echo  $msg;?>
                                          </div></center><?php }?>

                                     <script>
var close = document.getElementsByClassName("closebtn");
var i;

for (i = 0; i < close.length; i++) {
    close[i].onclick = function(){
        var div = this.parentElement;
        div.style.opacity = "0";
        setTimeout(function(){ div.style.display = "none"; }, 600);
    }
}
</script>
			

<br><br>
<link href="css/style2.css" rel="stylesheet">
<div class="containe">
  <div class="card"></div>
  <div class="card"><center><h1 class="title">New Stock</h1>
          <form action="Newupdate.php" method="post">
      <div class="input-containe">
          <input type="text" id="#{label}" name="rackno" required />
        <label for="#{label}">RackNo</label>
        <div class="bar"></div>
      </div>
      <div class="input-containe">
          <input type="text"  class="date-picker"  name="pname" required/>
        <label for="#{label}">Product Name</label>
        <div class="bar"></div>
      </div>
        <div class="input-containe">
          <input type="text"   name="quan" required/>
        <label for="#{label}">Quantity</label>
        <div class="bar"></div>
      </div>
       
      
        
                                                    <div class="button-containe" >
        <button name="go" style="background-color:#357ae8" ><span>Go</span></button>
      </div>
                                                   

    </form>
  </div>
   <br><br>

</div>
        
                                                              <?php if(!empty($msg)){  unset($msg);}?>

        
                </div>
                
                
                
                
                
                
            </div><!--/.box-->
        </div><!--/.container-->
    </section><!--/#services-->

    <footer id="footer">
        <div class="container">
            <div class="row">
            <enter>
<?php echo "<p><center>Copyright &copy; 1998 - " . date("Y") . " Kamaraj  of College Engineering & Technology</center></p>"; ?>
                    </enter>  </div>
               
        </div>
    </footer><!--/#footer-->

</body>
</html>