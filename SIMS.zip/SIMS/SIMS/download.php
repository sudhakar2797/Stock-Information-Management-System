
<?php
 require('fpdf.php');

class PDF extends FPDF
{
// Page header
function Header()
{
// Logo
	$this->Image('images/kcet.png',100,6,100,15);
	// Arial bold 15
	
}

// Page footer
function Footer()
{
	// Position at 1.5 cm from bottom
	$this->SetY(-10);
                $this->SetX(0);

	// Arial italic 8
	$this->SetFont('Arial','I',8);
	// Page number
	$this->Cell(0,10,'Page '.$this->PageNo(),0,0,'C');

        
    date_default_timezone_set('Asia/Kolkata');
$date=date('d-m-Y h:i:sa');
	// Position at 1.5 cm from bottom
	$this->SetY(-11);
        $this->SetX(140);
	// Arial italic 8
	$this->SetFont('Arial','B',11);
		$this->Cell(0,0,$date,0,0,'C');

}
}



// Instanciation of inherited class
$pdf = new PDF();
$pdf->AddPage('L','A4');
	     
//Fields Name position
$Y_Fields_Name_position = 30;
//Table position, under Fields Name
$Y_Table_Position = 36;

//First create each Field Name
//Gray color filling each Field Name box
$pdf->SetFillColor(232,232,232);
//Bold Font for Field Name
$pdf->SetFont('Arial','B',10);
$pdf->SetY($Y_Fields_Name_position);

$pdf->SetX(8);
$pdf->Cell(26,6,'RackNo',1,0,'L',1);
$pdf->SetX(34);
$pdf->Cell(26,6,'ProductID',1,0,'L',1);
$pdf->SetX(60);
$pdf->Cell(210,6,'Product Name',1,0,'L',1);
$pdf->SetX(270);
$pdf->Cell(20,6,'Quantity',1,0,'L',1);

$pdf->Ln();

//Connect to your database
include("dbconnect.php");

//Select the Products you want to show in your PDF file
$query="select * from stock";
$sql = $conn->query($query);
$number_of_records = $sql->num_rows;

while ($row=$sql->fetch_assoc()){
    $rid=$row['RackNo'];
    $pid=$row['ProductID'];
    $pname=$row['ProductName'];
    $quan=$row['Quantity'];
    

    
   
    
//Now show the 3 columns
$pdf->SetFont('Arial','',10);
$pdf->SetY($Y_Table_Position);
$pdf->SetX(8);

$pdf->MultiCell(26,6,$rid,1);
$pdf->SetY($Y_Table_Position);
$pdf->SetX(34);
$pdf->MultiCell(26,6,$pid,1);
$pdf->SetY($Y_Table_Position);
$pdf->SetX(60);
$pdf->MultiCell(210,6,$pname,1);
$pdf->SetY($Y_Table_Position);
$pdf->SetX(270);
$pdf->MultiCell(20,6,$quan,1);
$pdf->SetY($Y_Table_Position);



$Y_Table_Position+=6;

if($Y_Table_Position>=180){$pdf->AddPage('L','A4');
	     
//Fields Name position
$Y_Fields_Name_position = 30;
//Table position, under Fields Name
$Y_Table_Position = 36;}





  }
//For each row, add the field to the corresponding column
$pdf->Output();
mysqli_close($conn);?>