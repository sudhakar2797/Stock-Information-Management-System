<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Stock Management System</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">

</head><!--/head-->

<body data-spy="scroll" data-target="#navbar" data-offset="0">
    <header id="header" role="banner">
        <div class="container">
            <div id="navbar" class="navbar navbar-default">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="welcome.php"></a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="#main-slider"><i class="icon-home"></i></a></li>
                        <li><a href="#services">Search</a></li>
                        <li><a href="#portfolio">Update</a></li>
                        <li><a href="#pricing">Display</a></li>
                        <li><a href="#about-us">About Us</a></li>
                        <li><a href="#contact">Contact</a></li>
                        <li><a href="#Logout">Logout</a></li>

                    </ul>
                </div>
            </div>
        </div>
    </header><!--/#header-->

    <section id="main-slider" class="carousel">
        <div class="carousel-inner">
            <div class="item active">
                <div class="container">
                    <div class="carousel-content">
                        <h1>Stock Management System</h1>
                    </div>
                </div>
            </div><!--/.item-->
            <div class="item">
                <div class="container">
                    <div class="carousel-content">
                        <h1 style="font-size: 45px">Department of Mechanical Engineering</h1>
                    </div>
                </div>
            </div><!--/.item-->
        </div><!--/.carousel-inner-->
        
        
        
        
        <a class="prev" href="#main-slider" data-slide="prev"><i class="icon-angle-left"></i></a>
        <a class="next" href="#main-slider" data-slide="next"><i class="icon-angle-right"></i></a>
    </section><!--/#main-slider-->

    <section id="services">
        <div class="container">
            <div class="box first"><br><br><br><br><br><br>
                        <center><div class="center">
                                <a href="Search.php">
                                    <img src="ICON/dashboard-intro_search-bar.gif" style="width: 250px;width: 250px">
                            <h2>Search stock</h2>
                            <h4 style="color: #1586c3">Click  To Find The Product Details</h4>
                                    </a></div>
                        </center>
                   <br><br><br><br><br><br>
            </div><!--/.box-->
        </div><!--/.container-->
    </section><!--/#services-->

    <section id="portfolio">
        <div class="container">
            <div class="box"><br><br><br><br>
                <div class="center gap">
                    <div class="container" >
            <div class="box first" style="background-color: #fff"><br><br><br><br><br>
                        <center><div class="center">
                                <a href="Update.php">
                                    <img src="ICON/01d9a626480377.56363bd7bc047.gif" style="width: 250px;width: 250px">
                            <h2>Update stock</h2>
                            <h4 style="color: #1586c3">Click  To Update The Product Details</h4>
                                    </a></div>
                        </center>
                   <br><br><br><br><br><br>
            </div><!--/.box-->
        </div><!--/.container-->  </div><!--/.center-->
                  
            </div><!--/.box-->
        </div><!--/.container-->
    </section><!--/#portfolio-->

    <section id="pricing">
        <div class="container">
            <div class="box" style="background-color: #fff"><br><br><br><br><br>
                <div class="center"> 
            <br><br><br><br><br>
                        <center><div class="center">
                                <a href="Display.php">
                                    <img src="Icon/giphy.gif" style="width: 250px;width: 250px">
                            <h2>Display stock</h2>
                            <h4 style="color: #1586c3">Click  To View The Product Details</h4>
                                    </a></div>
                        </center>
                   <br><br><br><br><br><br>
                       

            </div><!--/.box-->
        </div><!--/.container-->
                </div> 
            </div> 
        </div>
    </section><!--/#pricing-->

    
    <section id="about-us">
        <div class="container">
            <div class="box"><br><br><br><br>
                <div class="center">
                    <h2>Meet the Team</h2>
                    <p class="lead">Kamaraj College of Engineering and Technology</p>
                    <p class="lead"><a href="http://www.kamarajengg.edu.in"> http://www.kamarajengg.edu.in</a></p>
                    <p class="lead">By </p>
                       <p class="lead">Department of Mechanical Engineering</p>

                    <a class="left-arrow" href="#team-scroller" data-slide="prev">
                        <i class="icon-angle-left icon-4x"></i>
                    </a>
                    <a class="right-arrow" href="#team-scroller" data-slide="next">
                        <i class="icon-angle-right icon-4x"></i>
                    </a>
                </div><!--/.carousel-->
                <br><br><br><br>
            </div><!--/.box-->
        </div><!--/.container-->
    </section><!--/#about-us-->
<center>
    <section id="contact" >

         <?php if(!empty($_SESSION['cmsg'])){?>
            <link href="css/alert.css" rel="stylesheet">
            <div class="alert info" style="padding:20px;border-radius: 0px;width: 300px;font-size: 20px" >
                                        <span class="closebtn">&times;</span>  
                                       <?php  echo $_SESSION['cmsg'];?>
                                     </div><?php }?>

                                     <script>
var close = document.getElementsByClassName("closebtn");
var i;

for (i = 0; i < close.length; i++) {
    close[i].onclick = function(){
        var div = this.parentElement;
        div.style.opacity = "0";
        setTimeout(function(){ div.style.display = "none"; }, 600);
    }
}</script>
        <div class="container" >
            <div class="box last" ><br><br><br><br><br>
                <div class="row" style="width: 50%">
                        <h1>Contact Us</h1>
                        <div class="status alert alert-success" style="display: none"></div>
                        <form id="main-contact-form" class="contact-form"  method="post" action="checkcontactus.php" role="form">
                            <div class="row">
                               
                                    <div class="form-group">
                                        <input type="text" class="form-control" required="required" name="semail" placeholder="Email address">
                                    </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <textarea name="msg" id="message" required="required" class="form-control" rows="8" placeholder="Message"></textarea>
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" name="send" class="btn btn-danger btn-lg">Send Message</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div><!--/.col-sm-6-->
                   
                </div><!--/.row-->
        </div><!--/.container-->
    </section><!--/#contact-->
</center><center>
<section id="Logout" style="background: #fff;width: 84.5%" >
    
    <br><br><br>    <br><br><br><br><br><br>
    <a href="index.php">
    <center>
        <img src="ICON/logout.gif" width="150px" height="150px;">
        <h2 style="color: #357ae8">Thank You For Accessing  Our Service !... </h2>
        <a>Click To Exit</a>
        
        
        
    </center></a>
    
    
    
    
    
    
</section></center>
    <footer id="footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
<?php echo "<p><center>Copyright &copy; 1998 - " . date("Y") . " Kamaraj  of College Engineering & Technology</center></p>"; ?>
                </div>
               
            </div>
        </div>
    </footer><!--/#footer-->

    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/main.js"></script>
</body>
                                                                      <?php if(!empty($_SESSION['cmsg'])){  unset($_SESSION['cmsg']);}?>

</html>
               
                                        
    
                                

