<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Stack Management System</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <style>
    .button{cursor: pointer;
  background: #33b5e5;
  width: 20%;
  border: 0;
  padding: 10px 15px;
  color: #ffffff;
  -webkit-transition: 0.3s ease;
  transition: 0.3s ease;
  border-radius: 25px;
    }
    .button:hover{
        background-color: #21a6d8;
    }
    

                    input[type=text] {
                        width: 190px;
                        height:44px;
                        box-sizing: border-box;
                        border: 2px solid #ccc;
                        border-radius: 4px;
                        font-size: 16px;
                        background-color: white;
                        background-repeat: no-repeat;
                        padding: 12px 20px 8px 45px;
                        -webkit-transition: width 0.4s ease-in-out;
                        transition: width 0.4s ease-in-out;
                    }
                    input[type=date]:focus {
                        width: 35%;
                    }
                 
    </style>
   </head><!--/head-->

<body data-spy="scroll" data-target="#navbar" data-offset="0">
    <header id="header" role="banner">
        <div class="container">
            <div id="navbar" class="navbar navbar-default">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="welcome.php"></a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="welcome.php"><i class="icon-home"></i></a></li>
                        <li><a href="Search.php">Search</a></li>

                        <li><a href="Update.php">Update</a></li>
                        <li><a href="Newupdate.php">New Product</a></li>
                        <li><a href="report.php">Report</a></li>

                        <li><a href="Display.php">Display</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </header><!--/#header-->

    <section id="main-slider" class="carousel" style="height: 100px">
        <div class="carousel-inner">
            <div class="item active">
                <div class="container">
                    <div class="carousel-content">
                        <h1>Report</h1>
                    </div>
                </div>
            </div><!--/.item-->
            <div class="item">
                <div class="container">
                    <div class="carousel-content">
                        <h1 style="font-size: 45px">Department of Mechanical Engineering</h1>
                    </div>
                </div>
            </div><!--/.item-->
        </div><!--/.carousel-inner-->
        
        
        
        
        <a class="prev" href="#main-slider" data-slide="prev"><i class="icon-angle-left"></i></a>
        <a class="next" href="#main-slider" data-slide="next"><i class="icon-angle-right"></i></a>
    </section><!--/#main-slider-->

    <section id="services">
        <div class="container">
            <div class="box first">
               
        

        <link rel="stylesheet" href="jq/jquery-ui.css">
        <script src="jq/jquery.js"></script>
        <script src="jq/jquery-ui.js"></script>
  <center><div  style="background-color: #fff;width: 85%; height: 1000px">
                        <center>  
                            <div class="card" align="center">
                                <form method="get" action="reportpdf.php">
                                        <center><img src="ICON/The-Pencil-by-Justin-Burns.gif" width="300px" height="280px"/></center><br><br>
                                        <input  style="background-image:url(images/from.png)" type="text" id="datepicker1" placeholder=" From Date..." name="from" required>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                                              <input  style="background-image:url(images/to.png)" type="text" id="datepicker2" placeholder=" To Date..." name="to" required>
 <br><br>
                                        <button class="button" name="showme">Show Me</button>      
                                    </form><br>
                            </div>
                        </center>
                   </div>
        </body> <script>
                $( function(){
                $( "#datepicker" ).datepicker();
                $( "#format" ).on( "change", function() {
                $( "#datepicker" ).datepicker( "option", "dateFormat", $( this ).val() );
                });
                });
                $( function() {
                $( "#datepicker1" ).datepicker();
                $( "#format" ).on( "change", function() {
                $( "#datepicker1" ).datepicker( "option", "dateFormat", $( this ).val() );
                });
                });
                $( function() {
                $( "#datepicker2" ).datepicker();
                $( "#format" ).on( "change", function() {
                $( "#datepicker1" ).datepicker( "option", "dateFormat", $( this ).val() );
                });
                });
            </script>
           


    
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
            </div><!--/.box-->
        </div><!--/.container-->
    </section><!--/#services-->

</body>
</html>