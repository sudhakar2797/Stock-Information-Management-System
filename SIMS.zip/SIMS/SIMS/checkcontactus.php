<?php     if (session_status() == PHP_SESSION_NONE) {session_start();}?>

<?php
if(isset($_POST['send'])){
              
                $subject = " Faculty Mangement System Query ";
                $message = "
                <html>
        <body style='width: 500px; border-radius: 1.5px; text-align: justify; border: 4px solid #357ae8 ;word-wrap: word-break; '>

            <div style= 'width: 500px; height:100px;'><p style='color:crimson; font-size:25px;font-family:calibre;text-align: center;'><br>QUERY<br><br><br>
                </div>
                        <pre style=' font-size:20px;font-family:calibre;'>   
    Sender Name                              :     ".$_POST['semail']." 
    
    Query                                          :     ".$_POST['msg']."

                        </pre>
      
        </body>
</html>";
                $to="sudhakar.it.12345@gmail.com";
                $from=$_POST['semail'];
                $headers  = "MIME-Version: 1.0" . "\r\n";
                $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                $headers .= 'From: '.$from."\r\n".
                            'X-Mailer: PHP/' . phpversion();		
                $res=mail($to,$subject, $message, $headers); 
                if ($res) {
              $_SESSION['cmsg']= "Successfully Send";
              header("location:contactus.php");
                }else
                {
               $_SESSION['cmsg']= "Please Try Again";
                             header("location:contactus.php");
                }
    
               }
    
?>